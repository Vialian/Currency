# from Database import Database
# from Database import Database
# from _typeshed import Self
import json
from os import path
from re import I, split
import flask
from gcloud import storage
from pyasn1_modules.rfc2459 import CountryName

from six import string_types
import Database
import firebase
from flask import Flask, redirect, url_for, render_template, request, session
import uuid
import calculations
import datetime
# from flask_sqlalchemy import SQLAlchemy
#coding=utf-8

app = Flask(__name__)
app.secret_key = "test"

# db = SQLAlchemy(app) 


@app.route("/")
def home():
    if "user" not in session:
        return redirect(url_for("login"))   

   
    return render_template("index.html", name=session["user"])


@app.route("/gallery", methods=["POST", "GET"])
def gallery():

    if "user" not in session:
        return redirect(url_for("login"))
    
    if request.method == "POST":
        country = request.form['country']
        # data = []
        # data = calculations.getImages(country, session['user'])
        files = firebase.getAllFiles()
        data = []
        for file in files:
            test = str(file)
            b = test.split(",")[-1].replace(">","")
            
            try:
                l = b.split('/')
                if session['user'] in l[0]:
                    if country in l[1]:
                        data.append({'name':l[2],'src': firebase.getUrl(b[1:])})
            except:
                print("no folder")

        return render_template("gallery.html", country = country, data = data)
    return render_template("gallery.html")


@app.route("/add", methods=["POST", "GET"])
def add():
    if "user" not in session:
        return redirect(url_for("login"))
    else:
        if request.method == 'POST':
        # test = request.form['username']
        # print(test)
            if 'file' not in request.files:
                return "fejl"
            files = request.files.getlist('file')
            country = request.form['country']
            tempCountry = []
            for sessionCountry in session['countries']:
                tempCountry.append(sessionCountry)
            tempCountry.append(country)
            session.pop("countries", None)
            session['countries'] = tempCountry
            date = str(datetime.datetime.now())
            date = date.replace(" ","")
            date = date.replace("-","")
            date = date.replace(".","")
            date = date.replace(":","")

            print(date)

            for file in files:
                path = session["user"] + "/" + country + "/" + str(date) + file.filename
                firebase.upload(path, file)
                   
        
        return render_template("add.html")

@app.route("/addPicture", methods=["POST", "GET"])
def addPicture():

    if request.method == 'POST':


        myUUID = str(uuid.uuid4())
        print(f"UUID/GUID -> {myUUID}")
        country = request.form['url']
        if country == "all":
            data = {'guid':myUUID, "path":session['user']}
        else:
            data = {'guid':myUUID, "path":session['user'] + "/" + country}
        path = "tempUrl"
        ip_address = flask.request.remote_addr
        url = ip_address + ":5000/gallery/" + myUUID
        firebase.putDatabase(path, data)
        return render_template("guid.html", guid=url)
    return redirect(url_for("home"))


@app.route("/new")
def newUser():


    if "user" not in session:
        return redirect(url_for("login"))
    path = "tempUrl"
    myUUID = str(uuid.uuid4())
    # data = json.dumps(myUUID)
    data = {'guid':myUUID, "path":session['user']}
    firebase.putDatabase(path, data)

    return render_template("newUser.html")



@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        # session.permanent = True
        user = request.form["username"]
        session["user"] = user
        print(session["user"])


        files = firebase.getAllFiles()
        countries = []

        for file in files:
            test = str(file)
            b = test.split(",")[-1].replace(">","")
            try:
                l = b.split('/')

                if session['user'] in l[0]:
                    if l[1] != "":
                        if l[1] not in countries:
                            countries.append(l[1])
            except:
                print("no folder")
        session['countries'] = countries

        return redirect(url_for("home"))
    else:
        return render_template("login.html")



@app.route("/logout")
def logout():
    session.pop("user", None)
    session.pop("countries", None)
    return redirect(url_for("login"))

@app.route("/delete", methods=["POST", "GET"])
def user():
    if "user" in session:
        
        user = session["user"]

        imageCountry = request.form['imageCountry']

        imagename = request.form['imageAlt']
        print(imagename)
        temp = user + "/" + imageCountry + "/" + imagename;
        # temp = user + "/" + imageCountry + "/";
        # firebase.delete(temp)
        print(temp)
        firebase.download(temp, imagename)
        return f"<h1>{user}</h1>"
    else:
        return  redirect(url_for("login"))


@app.route("/gallery/<guid>")
def name2(guid):

    db = firebase.getDatabase(guid)
    apath = []
    path = ""
    for values in db.each():
        tempPath = str(values.val()['path'])
    
    path = tempPath.split('/')


    files = firebase.getAllFiles()
    data = []
    if len(path) == 2:
        for file in files:
            test = str(file)
            b = test.split(",")[-1].replace(">","")
            
            try:
                l = b.split('/')
                if path[0] in l[0]:
                    if path[1] in l[1]:
                        data.append({'name':l[2],'src': firebase.getUrl(b[1:])})
            except:
                print("no folder")
        print(data)

        return render_template("tempUrl.html", country = path[1], data = data)

    if len(path) == 1:
        for file in files:
            test = str(file)
            b = test.split(",")[-1].replace(">","")
            try:
                l = b.split('/')
                
                if path[0] in l[0]:
                    data.append({'name':l[2],'src': firebase.getUrl(b[1:])})
            except:
                print("no folder")
        print(data)

        return render_template("tempUrl.html", country = path[0], data = data)
    


@app.route("/<name>")
def name(name):
    return redirect(url_for("home"))



if __name__ == "__name__":
    app.run(debug=True)