from datetime import date, datetime
from os import path
import urllib
from dns.rdataclass import NONE
from gcloud.storage import bucket
import pyrebase
from pyrebase.pyrebase import Auth, Firebase




firebaseConfig={ 
    'databaseURL': "https://globe-281c7-default-rtdb.europe-west1.firebasedatabase.app",
    'apiKey': "AIzaSyCtZlMITohL-cOuhFgVJeiAOHla75164hQ",
    'authDomain': "globe-281c7.firebaseapp.com",
    'projectId': "globe-281c7",
    'storageBucket': "globe-281c7.appspot.com",
    'messagingSenderId': "820318390076",
    'appId': "1:820318390076:web:9b0ac9a9bc959e50660039",
    'measurementId': "G-VVRF4MGVKX",
    'serviceAccount': "firebase\globe-281c7-firebase-adminsdk-wyinj-ac71f78943.json"

}

firebase=pyrebase.initialize_app(firebaseConfig)

storage=firebase.storage()
auth=firebase.auth()
db=firebase.database()
# Auth
def login():


    email="asdf@gmail.com"
    password="asdfgh"
    try:
        auth.sign_in_with_email_and_password(email,password)
        print("Login successful")
    except:
        print("Invalid email or password")

def logout():

    email="asdf@gmail.com"
    password="asdfgh"
    try:
        auth.current_user = "test"
        print("Login successful")
    except:
        print("Invalid email or password")


def download(path,file):
    storage=firebase.storage()
    storage.download(path, file)


# Storage
def upload(path,file):
    storage=firebase.storage()

    try:
        storage.child(path).put(file)
    except:
        print("error, file already exists!")
    
def delete(path):
    storage=firebase.storage()
    print("llllllllll")
    # storage.delete("test2");
    # storage.delete("test2")


def getUrl(path):
 

    files = storage.child(path).get_url(None)
    return files

def getAllFiles():
    allFiles = storage.list_files()
    return allFiles
    
    # for file in allFiles:
    #     print(file)
def getAllFilesPrefix(path):
    allFiles = storage.child(path).list_files()
    return allFiles
    


def putDatabase(path,data):
    db.push(data)
    # test = {'age': 40, 'address':"new York", 'employed':True, 'name':"John Smith"}
    
    db.child(path).push(data)
    print("test")

def getDatabase(guid):
    return db.child("tempUrl").order_by_child("guid").equal_to(guid).get()