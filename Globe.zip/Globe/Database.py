import mysql.connector
from mysql.connector import Error



#     MyDB = mysql.connector.connect(
#             host="127.0.0.1",
#             user="root",
#             password="Kagemand123",
#             database="Globe"
#     )
#     if connection.is_connected():
#         db_Info = connection.get_server_info()
#         print("Connected to MySQL Server version ", db_Info)
#         cursor = connection.cursor()
#         cursor.execute("select database();")
#         record = cursor.fetchone()
#         print("You're connected to database: ", record)
# except Error as e:
#     print("Error while connecting to MySQL", e)
# finally:
#     if connection.is_connected():
#         cursor.close()
#         connection.close()
#         print("MySQL connection is closed")

# MyCursor = MyDB.cursor()

# MyCursor.execute("CREATE TABLE IF NOT EXISTS Images (id INTEGER(45) NOT NULL AUTO_INCREMENT PRIMARY KEY, photo, LONGBLOB NOT NULL")


# def InsertBlob(Filepath):
    
#     # with open(Filepath, "rb") as File:
#     with open("773831.jpg", "rb") as File:
#         BinaryData = File.read()
#     SQLStatement = "INSERT INTO Images (photo) VALUES (%s)"
#     MyCursor.execute(SQLStatement, (BinaryData))
#     MyDB.commit()


# def RetriveBlob(ID):
#     SQLStatement2 = "SELECT * FROM Images WHERE id = '{0}'"
#     MyCursor.execute(SQLStatement2.format(str(ID)))
#     MyResult = MyCursor.fetchone()[1]
#     StoreFilePath = "ImageOutputs/img{0}.jpg".format(str(ID))
#     print(MyResult)
#     with open(StoreFilePath, "wb") as File:
#         File.write(MyResult)
#         File.close



# try:
#     connection  = mysql.connector.connect(
#             host="127.0.0.1",
#             user="root",
#             password="Kagemand123",
#             database="Globe"
#     )
#     if connection.is_connected():
#         db_Info = connection.get_server_info()
#         print("Connected to MySQL Server version ", db_Info)
#         cursor = connection.cursor()
#         cursor.execute("select database();")
#         record = cursor.fetchone()
#         print("You're connected to database: ", record)

# except Error as e:
#     print("Error while connecting to MySQL", e)


def test():
    #connect to mysql server
    try:
        connection  = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="Kagemand123",
                database="Globe"
        )
        if connection.is_connected():
            db_Info = connection.get_server_info()
            print("Connected to MySQL Server version ", db_Info)
            cursor = connection.cursor()
            cursor.execute("select database();")
            record = cursor.fetchone()
            print("You're connected to database: ", record)

    except Error as e:
        print("Error while connecting to MySQL", e)

    
    sql = "select * from persons;"
    cursor.execute(sql)
    answer = cursor.fetchall()
    print("svar: ", answer)
    # connection.commit()

    cursor.close()
    connection.close()
    print("MySQL connection is closed")


# personID,firstName,lastName,userName,kodeord
def insert(firstName,lastName,userName,kodeord):
    
    try:
        connection  = mysql.connector.connect(
                host="127.0.0.1",
                user="root",
                password="Kagemand123",
                database="Globe"
        )
        if connection.is_connected():
            db_Info = connection.get_server_info()
            print("Connected to MySQL Server version ", db_Info)
            cursor = connection.cursor()
            cursor.execute("select database();")
            record = cursor.fetchone()
            print("You're connected to database: ", record)

    except Error as e:
        print("Error while connecting to MySQL", e)


    sql = "INSERT INTO persons (FirstName, LastName, UserName, Kodeord) VALUES (%s, %s, %s, %s)"
    val = (firstName,lastName,userName,kodeord)
    cursor.execute(sql,val)
    connection.commit()
    print("svar: commited")

    cursor.close()
    connection.close()
    print("MySQL connection is closed")



# def test():
#     try:
#         connection  = mysql.connector.connect(
#                 host="127.0.0.1",
#                 user="root",
#                 password="Kagemand123",
#                 database="Globe"
#         )
#         if connection.is_connected():
#             db_Info = connection.get_server_info()
#             print("Connected to MySQL Server version ", db_Info)
#             cursor = connection.cursor()
#             cursor.execute("select database();")
#             record = cursor.fetchone()
#             print("You're connected to database: ", record)

#             sql = "select * from persons;"
#             cursor.execute(sql)
#             answer = cursor.fetchall()
#             print("svar: ", answer)
#             # connection.commit()

#     except Error as e:
#         print("Error while connecting to MySQL", e)
#     finally:
#         if connection.is_connected():
#             cursor.close()
#             connection.close()
#             print("MySQL connection is closed")
    

# class sql:
#     def __init__(self):
#         try:
#             self.connection  = mysql.connector.connect(
#                     host="127.0.0.1",
#                     user="root",
#                     password="Kagemand123",
#                     database="Globe"
#             )
#             if self.connection.is_connected():
#                 db_Info = self.connection.get_server_info()
#                 print("Connected to MySQL Server version ", db_Info)
#                 self.cursor = self.connection.cursor()
#                 self.cursor.execute("select database();")
#                 record = self.cursor.fetchone()
#                 print("You're connected to database: ", record)

#         except Error as e:
#             print("Error while connecting to MySQL", e)


#     def test(self):
#         sqlcmd = "select * from persons;"
#         self.cursor.execute(sqlcmd)
#         answer = self.cursor.fetchall()
#         print("svar: ", answer)
#         # connection.commit()

#         self.cursor.close()
#         self.connection.close()
#         print("MySQL connection is closed")
