import firebase
def getImages(country, user):
    files = firebase.getAllFiles()
    data = []
    for file in files:
        test = str(file)
        b = test.split(",")[-1].replace(">","")
        
        try:
            l = b.split('/')
            
            if user in l[0]:
                if country in l[1]:
                    data.append({'name':l[2],'src': firebase.getUrl(b[1:])})
        except:
            print("no folder")